package com.huy.shopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.huy.shopping.entity.User;
import com.huy.shopping.repository.UserRepository;

@Controller
@RequestMapping("/admin/users")
public class AdminUserController {
    @Autowired UserRepository repo;
    BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    @GetMapping
    public String list(@RequestParam(defaultValue = "") String keyword,
                       @RequestParam(defaultValue = "0") int page, Model model) {
        Page<User> result = repo.findByUsernameContainingOrFullnameContaining(
                keyword, keyword, PageRequest.of(page, 5, Sort.by("id")));
        model.addAttribute("page", result);
        model.addAttribute("keyword", keyword);
        return "user/list";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("user", new User());
        return "user/form";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("user", repo.findById(id).orElseThrow());
        return "user/form";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute User user) {
        if (user.getId() != null && (user.getPassword() == null || user.getPassword().isBlank())) {
            // sửa mà để trống mật khẩu: giữ mật khẩu cũ
            user.setPassword(repo.findById(user.getId()).orElseThrow().getPassword());
        } else {
            user.setPassword(encoder.encode(user.getPassword()));
        }
        repo.save(user);
        return "redirect:/admin/users";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        repo.deleteById(id);
        return "redirect:/admin/users";
    }
}