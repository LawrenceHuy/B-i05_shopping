package com.huy.shopping.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.huy.shopping.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    boolean existsByUsername(String username);

    // dòng mới thêm: tìm User theo username hoặc họ tên, có phân trang
    Page<User> findByUsernameContainingOrFullnameContaining(String username, String fullname, Pageable pageable);
}