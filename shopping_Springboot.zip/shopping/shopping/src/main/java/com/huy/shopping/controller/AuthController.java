package com.huy.shopping.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.huy.shopping.entity.User;
import com.huy.shopping.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {
    @Autowired UserRepository repo;
    BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    @GetMapping("/register")
    public String registerForm() { return "register"; }

    @PostMapping("/register")
    public String register(User user, Model model) {
        if (repo.existsByUsername(user.getUsername())) {
            model.addAttribute("error", "Username đã tồn tại");
            return "register";
        }
        user.setPassword(encoder.encode(user.getPassword()));
        user.setRole("USER");
        repo.save(user);
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginForm() { return "login"; }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password,
                        HttpSession session, Model model) {
        Optional<User> u = repo.findByUsername(username);
        if (u.isPresent() && encoder.matches(password, u.get().getPassword())) {
            session.setAttribute("user", u.get());
            return "redirect:/home";
        }
        model.addAttribute("error", "Sai tài khoản hoặc mật khẩu");
        return "login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/home")
    public String home() { return "home"; }
}