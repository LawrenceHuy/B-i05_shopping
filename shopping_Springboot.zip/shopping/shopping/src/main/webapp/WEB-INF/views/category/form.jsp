<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Category</title></head>
<body>
<h2>${empty category.id ? 'Thêm' : 'Sửa'} Category</h2>
<form method="post" action="${ctx}/admin/categories/save">
    <input type="hidden" name="id" value="${category.id}">
    Tên: <input name="name" value="${category.name}" required><br><br>
    Mô tả: <input name="description" value="${category.description}"><br><br>
    <button>Lưu</button>
    <a href="${ctx}/admin/categories">Hủy</a>
</form>
</body>
</html>