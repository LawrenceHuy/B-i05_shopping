<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Đăng ký</title></head>
<body>
    <h2>Đăng ký</h2>
    <form method="post" action="${pageContext.request.contextPath}/register">
        <input name="fullname" placeholder="Họ tên" required><br><br>
        <input name="username" placeholder="Username" required><br><br>
        <input name="password" type="password" placeholder="Password" required><br><br>
        <button type="submit">Đăng ký</button>
        <p style="color:red">${error}</p>
    </form>
    <a href="${pageContext.request.contextPath}/login">Đã có tài khoản? Đăng nhập</a>
</body>
</html>