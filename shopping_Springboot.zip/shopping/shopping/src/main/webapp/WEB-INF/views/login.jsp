<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Đăng nhập</title></head>
<body>
    <h2>Đăng nhập</h2>
    <form method="post" action="${pageContext.request.contextPath}/login">
        <input name="username" placeholder="Username" required><br><br>
        <input name="password" type="password" placeholder="Password" required><br><br>
        <button type="submit">Đăng nhập</button>
        <p style="color:red">${error}</p>
    </form>
    <a href="${pageContext.request.contextPath}/register">Chưa có tài khoản? Đăng ký</a>
</body>
</html>