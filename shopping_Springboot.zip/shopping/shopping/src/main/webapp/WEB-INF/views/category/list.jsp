<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<h2>Quản lý Category</h2>
<form method="get" action="${ctx}/admin/categories">
    <input name="keyword" value="${keyword}" placeholder="Tìm theo tên">
    <button>Tìm</button>
    <a href="${ctx}/admin/categories/add">+ Thêm mới</a>
</form>
<table border="1" cellpadding="6">
    <tr><th>ID</th><th>Tên</th><th>Mô tả</th><th>Thao tác</th></tr>
    <c:forEach var="cat" items="${page.content}">
        <tr>
            <td>${cat.id}</td><td>${cat.name}</td><td>${cat.description}</td>
            <td>
                <a href="${ctx}/admin/categories/edit/${cat.id}">Sửa</a>
                <form method="post" action="${ctx}/admin/categories/delete/${cat.id}"
                      style="display:inline" onsubmit="return confirm('Xóa?')">
                    <button>Xóa</button>
                </form>
            </td>
        </tr>
    </c:forEach>
</table>
<c:if test="${page.totalPages > 0}">
    <c:forEach begin="0" end="${page.totalPages - 1}" var="i">
        <a href="${ctx}/admin/categories?page=${i}&keyword=${keyword}">
            ${i == page.number ? '<b>' : ''}${i + 1}${i == page.number ? '</b>' : ''}
        </a>
    </c:forEach>
</c:if>
<p><a href="${ctx}/home">← Trang chủ</a></p>