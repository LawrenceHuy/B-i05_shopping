<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Trang chủ</title></head>
<body>
    <h2>Xin chào, ${sessionScope.user.fullname}!</h2>
    <p>Quyền: ${sessionScope.user.role}</p>
    <c:if test="${sessionScope.user.role == 'ADMIN'}">
        <a href="${pageContext.request.contextPath}/admin/categories">Quản lý Category</a> |
        <a href="${pageContext.request.contextPath}/admin/users">Quản lý User</a><br><br>
    </c:if>
    <a href="${pageContext.request.contextPath}/logout">Đăng xuất</a>
</body>
</html>