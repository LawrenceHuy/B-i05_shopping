<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<h2>${empty user.id ? 'Thêm' : 'Sửa'} User</h2>
<form method="post" action="${ctx}/admin/users/save">
    <input type="hidden" name="id" value="${user.id}">
    Username: <input name="username" value="${user.username}" required><br><br>
    Họ tên: <input name="fullname" value="${user.fullname}"><br><br>
    Mật khẩu: <input name="password" type="password" ${empty user.id ? 'required' : ''}>
    ${empty user.id ? '' : '(để trống nếu không đổi)'}<br><br>
    Quyền:
    <select name="role">
        <option value="USER" ${user.role == 'USER' ? 'selected' : ''}>USER</option>
        <option value="ADMIN" ${user.role == 'ADMIN' ? 'selected' : ''}>ADMIN</option>
    </select><br><br>
    <button>Lưu</button>
    <a href="${ctx}/admin/users">Hủy</a>
</form>