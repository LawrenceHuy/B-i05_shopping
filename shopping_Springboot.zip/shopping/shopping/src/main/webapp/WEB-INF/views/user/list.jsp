<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<h2>Quản lý User</h2>
<form method="get" action="${ctx}/admin/users">
    <input name="keyword" value="${keyword}" placeholder="Tìm theo username / họ tên">
    <button>Tìm</button>
    <a href="${ctx}/admin/users/add">+ Thêm mới</a>
</form>
<table border="1" cellpadding="6">
    <tr><th>ID</th><th>Username</th><th>Họ tên</th><th>Quyền</th><th>Thao tác</th></tr>
    <c:forEach var="u" items="${page.content}">
        <tr>
            <td>${u.id}</td><td>${u.username}</td><td>${u.fullname}</td><td>${u.role}</td>
            <td>
                <a href="${ctx}/admin/users/edit/${u.id}">Sửa</a>
                <form method="post" action="${ctx}/admin/users/delete/${u.id}"
                      style="display:inline" onsubmit="return confirm('Xóa?')">
                    <button>Xóa</button>
                </form>
            </td>
        </tr>
    </c:forEach>
</table>
<c:if test="${page.totalPages > 0}">
    <c:forEach begin="0" end="${page.totalPages - 1}" var="i">
        <a href="${ctx}/admin/users?page=${i}&keyword=${keyword}">
            ${i == page.number ? '<b>' : ''}${i + 1}${i == page.number ? '</b>' : ''}
        </a>
    </c:forEach>
</c:if>
<p><a href="${ctx}/home">← Trang chủ</a></p>